export default function VideoBanner() {
  return (
    <section
      style={{
        position: 'relative',
        height: '70vh',
        minHeight: 500,
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {/* Background */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `url('https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1920&h=1080&fit=crop&auto=format')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center 30%',
          filter: 'brightness(0.22) saturate(0.5)',
        }}
      />

      {/* Gradient overlays */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(180deg, rgba(5,5,5,0.5) 0%, rgba(5,5,5,0.2) 50%, rgba(5,5,5,0.7) 100%)',
        }}
      />

      {/* Content */}
      <div style={{ position: 'relative', zIndex: 2, textAlign: 'center', padding: '0 24px' }}>
        <p
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: 11,
            fontWeight: 500,
            letterSpacing: '0.22em',
            color: 'rgba(255,255,255,0.4)',
            textTransform: 'uppercase',
            marginBottom: 24,
          }}
        >
          Behind The Brand
        </p>
        <h2
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontWeight: 700,
            fontSize: 'clamp(36px, 5.5vw, 80px)',
            letterSpacing: '-0.03em',
            color: '#fff',
            lineHeight: 1,
            maxWidth: 800,
            margin: '0 auto 48px',
          }}
        >
          Crafted For Everyday Confidence
        </h2>

        <button
          className="glass-btn"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 12,
            padding: '16px 36px',
            fontFamily: "'Inter', sans-serif",
            fontWeight: 500,
            fontSize: 13,
            letterSpacing: '0.08em',
            textTransform: 'uppercase',
            color: '#fff',
            cursor: 'pointer',
            border: '1px solid rgba(255,255,255,0.15)',
          }}
        >
          <span
            style={{
              width: 32,
              height: 32,
              background: 'rgba(255,255,255,0.12)',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
          </span>
          Watch Story
        </button>
      </div>
    </section>
  )
}
