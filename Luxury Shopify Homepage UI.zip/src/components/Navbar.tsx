import { useState, useEffect } from 'react'

const navLinks = [
  { label: 'T-Shirts', href: '#collection' },
  { label: 'Trousers', href: '#', badge: 'Soon' },
  { label: 'Fragrances', href: '#', badge: 'Soon' },
  { label: 'New Drop', href: '#collection', highlight: true },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'nav-scrolled' : 'bg-transparent'}`}
      style={{ borderBottom: scrolled ? undefined : '1px solid transparent' }}
    >
      <div style={{ maxWidth: 1600, margin: '0 auto', padding: '0 40px' }}>
        <div className="flex items-center justify-between" style={{ height: 72 }}>
          {/* Logo */}
          <a href="#" className="flex items-center gap-3 no-underline">
            <div
              className="flex items-center justify-center"
              style={{
                width: 40,
                height: 40,
                background: 'rgba(255,255,255,0.08)',
                border: '1px solid rgba(255,255,255,0.15)',
                borderRadius: 10,
              }}
            >
              <span
                style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontWeight: 700,
                  fontSize: 16,
                  color: '#fff',
                  letterSpacing: '-0.02em',
                }}
              >
                NF
              </span>
            </div>
            <span
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontWeight: 600,
                fontSize: 15,
                letterSpacing: '0.12em',
                color: '#fff',
                textTransform: 'uppercase',
              }}
            >
              NUREXFIT
            </span>
          </a>

          {/* Desktop Nav Links */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="relative flex items-center gap-2 no-underline group"
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontWeight: link.highlight ? 600 : 400,
                  fontSize: 13,
                  letterSpacing: '0.06em',
                  color: link.highlight ? '#fff' : '#A8A8A8',
                  textTransform: 'uppercase',
                  transition: 'color 0.2s',
                }}
                onMouseEnter={(e) => { if (!link.badge) (e.currentTarget as HTMLElement).style.color = '#fff' }}
                onMouseLeave={(e) => { if (!link.badge) (e.currentTarget as HTMLElement).style.color = link.highlight ? '#fff' : '#A8A8A8' }}
              >
                {link.label}
                {link.badge && (
                  <span
                    style={{
                      fontSize: 9,
                      fontWeight: 600,
                      letterSpacing: '0.08em',
                      color: '#A8A8A8',
                      background: 'rgba(255,255,255,0.06)',
                      border: '1px solid rgba(255,255,255,0.10)',
                      borderRadius: 4,
                      padding: '2px 5px',
                      textTransform: 'uppercase',
                    }}
                  >
                    {link.badge}
                  </span>
                )}
              </a>
            ))}
          </div>

          {/* Right Icons */}
          <div className="hidden md:flex items-center gap-5">
            {[
              { icon: SearchIcon, label: 'Search' },
              { icon: UserIcon, label: 'Account' },
              { icon: HeartIcon, label: 'Wishlist' },
              { icon: BagIcon, label: 'Cart' },
            ].map(({ icon: Icon, label }) => (
              <button
                key={label}
                aria-label={label}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#A8A8A8',
                  cursor: 'pointer',
                  padding: 4,
                  transition: 'color 0.2s',
                  display: 'flex',
                  alignItems: 'center',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.color = '#fff')}
                onMouseLeave={(e) => (e.currentTarget.style.color = '#A8A8A8')}
              >
                <Icon />
              </button>
            ))}
          </div>

          {/* Mobile Hamburger */}
          <button
            className="md:hidden flex flex-col gap-1.5 p-2"
            style={{ background: 'none', border: 'none', cursor: 'pointer' }}
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            <span style={{ width: 22, height: 1.5, background: '#fff', display: 'block', transition: 'all 0.3s', transform: menuOpen ? 'rotate(45deg) translate(2px, 3px)' : 'none' }} />
            <span style={{ width: 22, height: 1.5, background: '#fff', display: 'block', opacity: menuOpen ? 0 : 1, transition: 'opacity 0.3s' }} />
            <span style={{ width: 22, height: 1.5, background: '#fff', display: 'block', transition: 'all 0.3s', transform: menuOpen ? 'rotate(-45deg) translate(2px, -3px)' : 'none' }} />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        style={{
          maxHeight: menuOpen ? 400 : 0,
          overflow: 'hidden',
          transition: 'max-height 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
          background: 'rgba(5,5,5,0.97)',
          backdropFilter: 'blur(24px)',
          borderTop: menuOpen ? '1px solid rgba(255,255,255,0.06)' : 'none',
        }}
      >
        <div style={{ padding: '24px 40px 32px' }}>
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="flex items-center gap-3 no-underline"
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontWeight: 500,
                fontSize: 20,
                letterSpacing: '0.04em',
                color: link.highlight ? '#fff' : '#A8A8A8',
                textTransform: 'uppercase',
                padding: '14px 0',
                borderBottom: '1px solid rgba(255,255,255,0.05)',
              }}
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
              {link.badge && (
                <span style={{ fontSize: 10, color: '#A8A8A8', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)', borderRadius: 4, padding: '2px 6px', letterSpacing: '0.08em' }}>
                  {link.badge}
                </span>
              )}
            </a>
          ))}
          <div className="flex gap-6 mt-6">
            {['Search', 'Account', 'Wishlist', 'Cart'].map((l) => (
              <span key={l} style={{ fontSize: 12, color: '#A8A8A8', letterSpacing: '0.08em', textTransform: 'uppercase', cursor: 'pointer' }}>{l}</span>
            ))}
          </div>
        </div>
      </div>
    </nav>
  )
}

function SearchIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
    </svg>
  )
}
function UserIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
    </svg>
  )
}
function HeartIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
  )
}
function BagIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /><path d="M16 10a4 4 0 0 1-8 0" />
    </svg>
  )
}
