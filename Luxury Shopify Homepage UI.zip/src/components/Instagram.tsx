const posts = [
  { id: 1, image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=500&h=500&fit=crop&auto=format', likes: '2.4K' },
  { id: 2, image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=500&h=500&fit=crop&auto=format', likes: '3.1K' },
  { id: 3, image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=500&h=500&fit=crop&auto=format', likes: '1.8K' },
  { id: 4, image: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=500&h=500&fit=crop&auto=format', likes: '4.2K' },
  { id: 5, image: 'https://images.unsplash.com/photo-1548549557-dbe9946621da?w=500&h=500&fit=crop&auto=format', likes: '2.9K' },
  { id: 6, image: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?w=500&h=500&fit=crop&auto=format', likes: '5.1K' },
]

export default function Instagram() {
  return (
    <section style={{ background: '#050505', padding: '100px 0 120px', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
      <div style={{ maxWidth: 1600, margin: '0 auto', padding: '0 40px' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 11,
              fontWeight: 500,
              letterSpacing: '0.22em',
              color: '#A8A8A8',
              textTransform: 'uppercase',
              marginBottom: 16,
            }}
          >
            Follow Along
          </p>
          <h2
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontWeight: 700,
              fontSize: 'clamp(32px, 4vw, 56px)',
              letterSpacing: '-0.03em',
              color: '#fff',
              lineHeight: 0.95,
              marginBottom: 16,
            }}
          >
            @NUREXFIT
          </h2>
          <a
            href="#"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 12,
              color: '#A8A8A8',
              textDecoration: 'none',
              letterSpacing: '0.04em',
              transition: 'color 0.2s',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#fff')}
            onMouseLeave={(e) => (e.currentTarget.style.color = '#A8A8A8')}
          >
            instagram.com/nurexfit
          </a>
        </div>

        {/* Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(6, 1fr)',
            gap: 8,
          }}
        >
          {posts.map((post) => (
            <div
              key={post.id}
              className="ig-item"
              style={{
                position: 'relative',
                aspectRatio: '1',
                borderRadius: 12,
                overflow: 'hidden',
                background: '#111',
                cursor: 'pointer',
              }}
            >
              <img
                src={post.image}
                alt={`NUREXFIT Instagram post ${post.id}`}
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  filter: 'brightness(0.75) saturate(0.65)',
                  transition: 'filter 0.3s, transform 0.4s cubic-bezier(0.4,0,0.2,1)',
                }}
              />
              <div
                className="ig-overlay"
                style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'rgba(5,5,5,0.55)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6,
                  opacity: 0,
                  transition: 'opacity 0.3s',
                }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                </svg>
                <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, fontWeight: 500, color: '#fff', letterSpacing: '0.04em' }}>
                  {post.likes}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
