export default function Hero() {
  return (
    <section
      style={{
        position: 'relative',
        height: '100vh',
        minHeight: 700,
        overflow: 'hidden',
        background: '#050505',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {/* Background image — dark cinematic fashion */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `url('https://images.unsplash.com/photo-1552902865-b72c031ac5ea?w=1920&h=1080&fit=crop&auto=format')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center 20%',
          filter: 'brightness(0.28) saturate(0.6)',
          transform: 'scale(1.04)',
          transition: 'transform 8s ease-out',
        }}
      />

      {/* Deep gradient overlay */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(180deg, rgba(5,5,5,0.3) 0%, rgba(5,5,5,0.15) 40%, rgba(5,5,5,0.7) 100%)',
        }}
      />

      {/* Subtle top edge fade */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: 200,
          background: 'linear-gradient(180deg, rgba(5,5,5,0.6) 0%, transparent 100%)',
        }}
      />

      {/* Content */}
      <div
        style={{
          position: 'relative',
          zIndex: 2,
          textAlign: 'center',
          padding: '0 24px',
          maxWidth: 900,
        }}
      >
        {/* Label */}
        <div
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 8,
            marginBottom: 40,
          }}
        >
          <span style={{ width: 24, height: 1, background: 'rgba(255,255,255,0.4)', display: 'inline-block' }} />
          <span
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 11,
              fontWeight: 500,
              letterSpacing: '0.22em',
              color: 'rgba(255,255,255,0.55)',
              textTransform: 'uppercase',
            }}
          >
            SS 2025 Collection
          </span>
          <span style={{ width: 24, height: 1, background: 'rgba(255,255,255,0.4)', display: 'inline-block' }} />
        </div>

        {/* Main heading */}
        <h1
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontWeight: 700,
            fontSize: 'clamp(56px, 8vw, 120px)',
            lineHeight: 0.95,
            letterSpacing: '-0.03em',
            color: '#ffffff',
            margin: '0 0 32px',
            textShadow: '0 0 80px rgba(255,255,255,0.06)',
          }}
        >
          WEAR YOUR<br />IDENTITY.
        </h1>

        {/* Subtitle */}
        <p
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: 'clamp(14px, 1.8vw, 18px)',
            fontWeight: 300,
            color: 'rgba(255,255,255,0.55)',
            letterSpacing: '0.04em',
            lineHeight: 1.7,
            marginBottom: 56,
            maxWidth: 480,
            margin: '0 auto 56px',
          }}
        >
          Premium Streetwear Designed For Those Who Stand Out.
        </p>

        {/* CTA Buttons */}
        <div className="flex items-center justify-center gap-4 flex-wrap">
          <a
            href="#collection"
            className="glass-btn-solid"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 10,
              padding: '16px 36px',
              fontFamily: "'Inter', sans-serif",
              fontWeight: 600,
              fontSize: 13,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              textDecoration: 'none',
              color: '#050505',
            }}
          >
            Shop Now
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </a>
          <a
            href="#lookbook"
            className="glass-btn"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 10,
              padding: '16px 36px',
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
              fontSize: 13,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              textDecoration: 'none',
              color: '#fff',
            }}
          >
            Explore Collection
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        style={{
          position: 'absolute',
          bottom: 40,
          left: '50%',
          transform: 'translateX(-50%)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 8,
          zIndex: 2,
        }}
      >
        <span
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: 10,
            letterSpacing: '0.2em',
            color: 'rgba(255,255,255,0.3)',
            textTransform: 'uppercase',
          }}
        >
          Scroll
        </span>
        <div
          style={{
            width: 1,
            height: 40,
            background: 'linear-gradient(180deg, rgba(255,255,255,0.3) 0%, transparent 100%)',
          }}
        />
      </div>
    </section>
  )
}
