const categories = [
  {
    title: 'T-Shirts',
    sub: 'Core Collection',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop&auto=format',
    href: '#collection',
    badge: null,
  },
  {
    title: 'Trousers',
    sub: 'Coming 2025',
    image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600&h=800&fit=crop&auto=format',
    href: '#',
    badge: 'Coming Soon',
  },
  {
    title: 'Fragrances',
    sub: 'Coming 2025',
    image: 'https://images.unsplash.com/photo-1541643600914-78b084683702?w=600&h=800&fit=crop&auto=format',
    href: '#',
    badge: 'Coming Soon',
  },
]

export default function Categories() {
  return (
    <section style={{ background: '#050505', padding: '100px 0 80px' }}>
      <div style={{ maxWidth: 1600, margin: '0 auto', padding: '0 40px' }}>
        {/* Section label */}
        <div style={{ marginBottom: 56, display: 'flex', alignItems: 'center', gap: 16 }}>
          <span
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 11,
              fontWeight: 500,
              letterSpacing: '0.2em',
              color: '#A8A8A8',
              textTransform: 'uppercase',
            }}
          >
            Shop By Category
          </span>
          <span style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.06)' }} />
        </div>

        {/* Cards grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: 16,
          }}
        >
          {categories.map((cat) => (
            <a
              key={cat.title}
              href={cat.href}
              className="category-card"
              style={{
                position: 'relative',
                borderRadius: 20,
                overflow: 'hidden',
                height: 520,
                cursor: 'pointer',
                textDecoration: 'none',
                display: 'block',
                background: '#111',
                border: '1px solid rgba(255,255,255,0.07)',
              }}
            >
              {/* Image */}
              <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', borderRadius: 20 }}>
                <img
                  src={cat.image}
                  alt={cat.title}
                  className="cat-img"
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                    filter: 'brightness(0.55) saturate(0.7)',
                    transition: 'transform 0.6s cubic-bezier(0.4, 0, 0.2, 1)',
                  }}
                />
              </div>

              {/* Gradient overlay */}
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'linear-gradient(180deg, transparent 40%, rgba(5,5,5,0.9) 100%)',
                  borderRadius: 20,
                }}
              />

              {/* Badge */}
              {cat.badge && (
                <div
                  style={{
                    position: 'absolute',
                    top: 20,
                    right: 20,
                    background: 'rgba(5,5,5,0.7)',
                    backdropFilter: 'blur(12px)',
                    border: '1px solid rgba(255,255,255,0.12)',
                    borderRadius: 8,
                    padding: '6px 12px',
                  }}
                >
                  <span
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 10,
                      fontWeight: 600,
                      letterSpacing: '0.12em',
                      color: '#A8A8A8',
                      textTransform: 'uppercase',
                    }}
                  >
                    {cat.badge}
                  </span>
                </div>
              )}

              {/* Text */}
              <div
                style={{
                  position: 'absolute',
                  bottom: 32,
                  left: 32,
                  right: 32,
                }}
              >
                <p
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: 11,
                    fontWeight: 500,
                    letterSpacing: '0.14em',
                    color: 'rgba(255,255,255,0.45)',
                    textTransform: 'uppercase',
                    marginBottom: 8,
                  }}
                >
                  {cat.sub}
                </p>
                <h3
                  style={{
                    fontFamily: "'Space Grotesk', sans-serif",
                    fontSize: 32,
                    fontWeight: 700,
                    letterSpacing: '-0.02em',
                    color: '#fff',
                    margin: 0,
                  }}
                >
                  {cat.title}
                </h3>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  )
}
