const products = [
  {
    id: 1,
    name: 'Void Oversized Tee',
    price: '£89',
    image: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600&h=750&fit=crop&auto=format',
    tag: 'New',
  },
  {
    id: 2,
    name: 'Shadow Box Tee',
    price: '£94',
    image: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=600&h=750&fit=crop&auto=format',
    tag: null,
  },
  {
    id: 3,
    name: 'Monolith Heavy Tee',
    price: '£99',
    image: 'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=600&h=750&fit=crop&auto=format',
    tag: 'Bestseller',
  },
  {
    id: 4,
    name: 'Contour Tee — Onyx',
    price: '£89',
    image: 'https://images.unsplash.com/photo-1562157873-818bc0726f68?w=600&h=750&fit=crop&auto=format',
    tag: null,
  },
]

export default function FeaturedCollection() {
  return (
    <section id="collection" style={{ background: '#050505', padding: '100px 0 120px' }}>
      <div style={{ maxWidth: 1600, margin: '0 auto', padding: '0 40px' }}>
        {/* Header */}
        <div
          style={{
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'space-between',
            marginBottom: 64,
            flexWrap: 'wrap',
            gap: 24,
          }}
        >
          <div>
            <p
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 11,
                fontWeight: 500,
                letterSpacing: '0.22em',
                color: '#A8A8A8',
                textTransform: 'uppercase',
                marginBottom: 16,
              }}
            >
              — SS 2025
            </p>
            <h2
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontWeight: 700,
                fontSize: 'clamp(40px, 5vw, 72px)',
                letterSpacing: '-0.03em',
                color: '#fff',
                lineHeight: 0.95,
                margin: 0,
              }}
            >
              NEW DROP
            </h2>
          </div>
          <a
            href="#"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 12,
              fontWeight: 500,
              letterSpacing: '0.1em',
              color: '#A8A8A8',
              textTransform: 'uppercase',
              textDecoration: 'none',
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              transition: 'color 0.2s',
              paddingBottom: 8,
              borderBottom: '1px solid rgba(255,255,255,0.15)',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#fff')}
            onMouseLeave={(e) => (e.currentTarget.style.color = '#A8A8A8')}
          >
            View All
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </a>
        </div>

        {/* Product Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
            gap: 20,
          }}
        >
          {products.map((p) => (
            <div
              key={p.id}
              className="product-card"
              style={{ cursor: 'pointer' }}
            >
              {/* Image container */}
              <div
                style={{
                  position: 'relative',
                  borderRadius: 16,
                  overflow: 'hidden',
                  background: '#111',
                  marginBottom: 20,
                  height: 400,
                }}
              >
                <img
                  src={p.image}
                  alt={p.name}
                  className="product-img"
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                    objectPosition: 'center top',
                    filter: 'brightness(0.88) saturate(0.75)',
                    transition: 'transform 0.6s cubic-bezier(0.4, 0, 0.2, 1)',
                  }}
                />

                {/* Tag */}
                {p.tag && (
                  <div
                    style={{
                      position: 'absolute',
                      top: 16,
                      left: 16,
                      background: 'rgba(5,5,5,0.75)',
                      backdropFilter: 'blur(12px)',
                      border: '1px solid rgba(255,255,255,0.10)',
                      borderRadius: 6,
                      padding: '5px 10px',
                    }}
                  >
                    <span
                      style={{
                        fontFamily: "'Inter', sans-serif",
                        fontSize: 10,
                        fontWeight: 600,
                        letterSpacing: '0.1em',
                        color: '#fff',
                        textTransform: 'uppercase',
                      }}
                    >
                      {p.tag}
                    </span>
                  </div>
                )}

                {/* Quick Add */}
                <div
                  className="quick-add"
                  style={{
                    position: 'absolute',
                    bottom: 16,
                    left: 16,
                    right: 16,
                  }}
                >
                  <button
                    style={{
                      width: '100%',
                      padding: '14px',
                      background: 'rgba(255,255,255,0.92)',
                      color: '#050505',
                      border: 'none',
                      borderRadius: 12,
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 12,
                      fontWeight: 600,
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      cursor: 'pointer',
                      backdropFilter: 'blur(12px)',
                      transition: 'background 0.2s',
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = '#fff')}
                    onMouseLeave={(e) => (e.currentTarget.style.background = 'rgba(255,255,255,0.92)')}
                  >
                    Quick Add
                  </button>
                </div>
              </div>

              {/* Product info */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <h3
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontWeight: 500,
                      fontSize: 15,
                      color: '#fff',
                      letterSpacing: '-0.01em',
                      margin: '0 0 4px',
                    }}
                  >
                    {p.name}
                  </h3>
                  <p
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 12,
                      color: '#A8A8A8',
                      letterSpacing: '0.04em',
                      margin: 0,
                    }}
                  >
                    T-Shirt
                  </p>
                </div>
                <span
                  style={{
                    fontFamily: "'Space Grotesk', sans-serif",
                    fontWeight: 600,
                    fontSize: 16,
                    color: '#fff',
                    letterSpacing: '-0.01em',
                  }}
                >
                  {p.price}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
