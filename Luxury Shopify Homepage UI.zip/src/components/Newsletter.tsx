import { useState } from 'react'

export default function Newsletter() {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email.trim()) setSubmitted(true)
  }

  return (
    <section
      style={{
        background: '#080808',
        padding: '140px 40px',
        borderTop: '1px solid rgba(255,255,255,0.06)',
        textAlign: 'center',
      }}
    >
      <div style={{ maxWidth: 600, margin: '0 auto' }}>
        <p
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: 11,
            fontWeight: 500,
            letterSpacing: '0.22em',
            color: '#A8A8A8',
            textTransform: 'uppercase',
            marginBottom: 24,
          }}
        >
          Stay Connected
        </p>
        <h2
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontWeight: 700,
            fontSize: 'clamp(36px, 5vw, 64px)',
            letterSpacing: '-0.03em',
            color: '#fff',
            lineHeight: 0.95,
            marginBottom: 20,
          }}
        >
          Join The Community
        </h2>
        <p
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: 15,
            fontWeight: 300,
            color: '#A8A8A8',
            lineHeight: 1.7,
            marginBottom: 56,
            letterSpacing: '0.01em',
          }}
        >
          Early access to new drops. No noise. Just NUREXFIT.
        </p>

        {submitted ? (
          <div
            className="glass"
            style={{
              borderRadius: 16,
              padding: '28px 40px',
            }}
          >
            <p
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: 18,
                fontWeight: 600,
                color: '#fff',
                letterSpacing: '-0.01em',
                margin: 0,
              }}
            >
              You're in. We'll be in touch.
            </p>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            style={{
              display: 'flex',
              gap: 10,
              maxWidth: 480,
              margin: '0 auto',
              flexWrap: 'wrap',
              justifyContent: 'center',
            }}
          >
            <input
              type="email"
              placeholder="Your email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={{
                flex: '1 1 220px',
                padding: '16px 24px',
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.10)',
                borderRadius: 18,
                fontFamily: "'Inter', sans-serif",
                fontSize: 14,
                color: '#fff',
                outline: 'none',
                backdropFilter: 'blur(20px)',
                transition: 'border-color 0.2s',
              }}
              onFocus={(e) => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.25)')}
              onBlur={(e) => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.10)')}
            />
            <button
              type="submit"
              className="glass-btn-solid"
              style={{
                padding: '16px 32px',
                fontFamily: "'Inter', sans-serif",
                fontSize: 13,
                fontWeight: 600,
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                cursor: 'pointer',
                color: '#050505',
                border: 'none',
                whiteSpace: 'nowrap',
              }}
            >
              Subscribe
            </button>
          </form>
        )}

        <p
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: 11,
            color: 'rgba(255,255,255,0.2)',
            marginTop: 20,
            letterSpacing: '0.04em',
          }}
        >
          No spam. Unsubscribe at any time.
        </p>
      </div>
    </section>
  )
}
