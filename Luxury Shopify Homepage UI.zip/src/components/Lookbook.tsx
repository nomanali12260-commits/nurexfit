const editorials = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800&h=1000&fit=crop&auto=format',
    title: 'The Void Edit',
    issue: 'Issue 01',
    large: true,
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=600&h=700&fit=crop&auto=format',
    title: 'Urban Solitude',
    issue: 'Issue 02',
    large: false,
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&h=700&fit=crop&auto=format',
    title: 'After Dark',
    issue: 'Issue 03',
    large: false,
  },
]

export default function Lookbook() {
  return (
    <section id="lookbook" style={{ background: '#050505', padding: '120px 0', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
      <div style={{ maxWidth: 1600, margin: '0 auto', padding: '0 40px' }}>
        {/* Header */}
        <div
          style={{
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'space-between',
            marginBottom: 56,
            flexWrap: 'wrap',
            gap: 24,
          }}
        >
          <div>
            <p
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 11,
                fontWeight: 500,
                letterSpacing: '0.22em',
                color: '#A8A8A8',
                textTransform: 'uppercase',
                marginBottom: 16,
              }}
            >
              — Editorial
            </p>
            <h2
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontWeight: 700,
                fontSize: 'clamp(36px, 4.5vw, 64px)',
                letterSpacing: '-0.03em',
                color: '#fff',
                lineHeight: 0.95,
                margin: 0,
              }}
            >
              LOOKBOOK
            </h2>
          </div>
          <a
            href="#"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 12,
              fontWeight: 500,
              letterSpacing: '0.1em',
              color: '#A8A8A8',
              textTransform: 'uppercase',
              textDecoration: 'none',
              paddingBottom: 8,
              borderBottom: '1px solid rgba(255,255,255,0.15)',
              transition: 'color 0.2s',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#fff')}
            onMouseLeave={(e) => (e.currentTarget.style.color = '#A8A8A8')}
          >
            Full Lookbook →
          </a>
        </div>

        {/* Magazine Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1.4fr 1fr',
            gridTemplateRows: 'auto auto',
            gap: 16,
          }}
        >
          {/* Large editorial */}
          <div
            className="lookbook-item"
            style={{
              gridRow: '1 / 3',
              position: 'relative',
              borderRadius: 20,
              overflow: 'hidden',
              height: 700,
              background: '#111',
              cursor: 'pointer',
              border: '1px solid rgba(255,255,255,0.06)',
            }}
          >
            <img
              src={editorials[0].image}
              alt={editorials[0].title}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                filter: 'brightness(0.65) saturate(0.7)',
                transition: 'transform 0.7s cubic-bezier(0.4, 0, 0.2, 1)',
              }}
            />
            <div
              style={{
                position: 'absolute',
                inset: 0,
                background: 'linear-gradient(180deg, transparent 40%, rgba(5,5,5,0.85) 100%)',
              }}
            />
            <div style={{ position: 'absolute', bottom: 36, left: 36 }}>
              <span
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 10,
                  fontWeight: 600,
                  letterSpacing: '0.15em',
                  color: 'rgba(255,255,255,0.4)',
                  textTransform: 'uppercase',
                  display: 'block',
                  marginBottom: 10,
                }}
              >
                {editorials[0].issue}
              </span>
              <h3
                style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontWeight: 700,
                  fontSize: 32,
                  letterSpacing: '-0.02em',
                  color: '#fff',
                  margin: 0,
                }}
              >
                {editorials[0].title}
              </h3>
            </div>
          </div>

          {/* Two smaller editorials */}
          {editorials.slice(1).map((ed) => (
            <div
              key={ed.id}
              className="lookbook-item"
              style={{
                position: 'relative',
                borderRadius: 20,
                overflow: 'hidden',
                height: 340,
                background: '#111',
                cursor: 'pointer',
                border: '1px solid rgba(255,255,255,0.06)',
              }}
            >
              <img
                src={ed.image}
                alt={ed.title}
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  filter: 'brightness(0.6) saturate(0.7)',
                  transition: 'transform 0.7s cubic-bezier(0.4, 0, 0.2, 1)',
                }}
              />
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'linear-gradient(180deg, transparent 40%, rgba(5,5,5,0.85) 100%)',
                }}
              />
              <div style={{ position: 'absolute', bottom: 28, left: 28 }}>
                <span
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: 10,
                    fontWeight: 600,
                    letterSpacing: '0.15em',
                    color: 'rgba(255,255,255,0.4)',
                    textTransform: 'uppercase',
                    display: 'block',
                    marginBottom: 8,
                  }}
                >
                  {ed.issue}
                </span>
                <h3
                  style={{
                    fontFamily: "'Space Grotesk', sans-serif",
                    fontWeight: 700,
                    fontSize: 22,
                    letterSpacing: '-0.02em',
                    color: '#fff',
                    margin: 0,
                  }}
                >
                  {ed.title}
                </h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
